import Cocoa

var greeting = "Hello, playground"
let tempCel = 9.0
var tempFar = tempCel * 9
tempFar /= 5
tempFar += 32
print( "\(tempCel)°C")
print("\(tempFar)°F")


var beatles = ["John", "Paul", "George", "Ringoo"]
let number = [4, 8, 15, 23, 42]
var tempuratures = [25.3, 28.2, 26.4]

print(beatles[0])
print(number[1])
print(tempuratures[2])

beatles.append("Adrian")
beatles.append("Alan")
print(beatles)

//create types of arrays
var scores = Array<Int>()
scores.append(100)
scores.append(45)
scores.append(60)
print(scores[1])

var albums = [String]()
albums.append("Folklore")
albums.append("Fearless")

print(albums.count)

var characters = ["Lana", "Pam", "Ray", "Sterling"]
print(characters.count)

characters.remove(at: 2)
print(characters.count)

characters.removeAll()
print(characters.count)

let bondMovies =  ["Casino Royale", "Spectre", "No Time To Die"]
print(bondMovies.contains("Frozen"))

let cities = ["London", "Tokyo", "Rome", "Budapest"]
print(cities.sorted())

let presidents = ["Bush", "Obama", "Trump", "Biden"]
let revesedPresidents = presidents.reversed()
print(revesedPresidents)

//dictionaries
let employee2 = [
    "name": "Taylor Swift",
    "job": "Singer",
    "location": "Nashville"
]
print(employee2["name", default: "Unknown"])
print(employee2["job", default: "Unknown"])
print(employee2["location", default: "Unknown"])

let hasGraduated = [
    "Eric": false,
    "Maeve": true,
    "Otis": false
]

let olympics = [
    2012: "London",
    2016: "Rio",
    2021: "Tokyo"
]

print(olympics[2012, default: "Unknown"])

var heights = [String: Int]()
heights["Yao Ming"] = 229
heights["Shaq"] = 216
heights["LeBron"] = 206

var archEnemies = [String: String]()
archEnemies["Batman"] = "Joker"
archEnemies["Superman"] = "Lex Luthor"
print(archEnemies["Batman", default: "Unknown"])
archEnemies["Batman"] = "Penguin"
print(archEnemies["Batman", default: "Unknown"])

//sets
//Creates an array inside a set
//Set doesn't care what order it comes in

//let actors = Set([
//    "Denzel",
//    "Tom Cruise",
//    "Nicolas Cage",
//    "Samuel L Jackson"
//])
//insert items
var actors = Set<String>()
actors.insert("Denzel")
actors.insert("Tom Cruise")
actors.insert("Nicolas Cage")
actors.insert("Samuel L Jackson")
print(actors)
//Using contains on a set it runs faster

//Enumeration  or enum
//enum Weekday {
//    case monday
//    case tuesday
//    case wednesday
//    case thursday
//    case friday
//}
// or do enums this way
enum Weekday {
    case monday, tuesday, wednesday, thursday, friday
}
//when assigning a value to a variable
var day = Weekday.monday
//day = Weekday.tuesday
//day = Weekday.friday
//or
day = .monday
day = .friday

//annotations assign the type to the variable instead of letting swift infer what it is
let surname: String = "Lasso"
//var score: Int = 0
//or
var score: Double = 0
let luckyNumber: Int = 13
let pi: Double =  3.141
var isAuthenticated: Bool = true
//array [data type]
var albums2: [String] = ["red", "fearless"]
//Dictionaries [data type: data type]
var user: [String: String] = ["id": "@twostraws"]
//Sets Set<data type>
var books: Set<String> = Set([
    "the bluest eye",
    "foundation",
    "Girl, Woman, Other"
])
//Good for empty
var teams: [String] = [String]()
var cities2: [String] = []
var clues = [String]()

//emuns annotations
enum UIStyle {
    case light, dark, system
}
var style = UIStyle.light
//same as
//var style: UIStyle = UIStyle.light
style = .dark

//Use annotation when the constant doesn't have a value
let username: String
//logic
username = "@twostraws"
//logic
print(username)
//golden rule swift must know what data type something will contain
//recap
//Arrays store many values, and read them using indices
//Dictionaries stors many values, and read them using keys we specify
//Sets stores many values, but we don't choose their order.  Faster to search through
//Enums create out own types to specify a range of acceptable values
//Swift uses type inference to figure what data we're storing
//It's also possible to use type annotation to force a particular type
//Arrays are the most commonly used

let checkpoint2: [String] = ["red", "red", "red", "blue", "yellow", "green"]
print(checkpoint2.count)
var checkpoint2A = Set(checkpoint2)
print(checkpoint2A.count)





