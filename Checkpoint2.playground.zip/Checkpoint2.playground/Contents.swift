import Cocoa

//----------------------------------------------------------------------------------------------------------------------------
//
// Checkpoint 2
//
//----------------------------------------------------------------------------------------------------------------------------

var checkPoint2: [String] = ["red","red","red","green","blue"]
print(checkPoint2.count)
var checkPoint2Set = Set(checkPoint2)
print(checkPoint2Set.count)


//----------------------------------------------------------------------------------------------------------------------------
//
// Check is condition is true or false
//
//----------------------------------------------------------------------------------------------------------------------------

var someCondition = true
if someCondition {
    print("Do something")
}

let score = 85
if score > 80 {
    print("Good Job!")
}

let speed = 88
let percentage = 85
let age = 18

if speed >= 88 {
    print("Where we're going we don't need roads")
}
if percentage < 85 {
    print("Sorry you failed the test")
}
if age >= 18 {
    print("You're eligible to vote.")
}

//if username is after other name when sorted alphabetically
let ourName = "Dave Lister"
let friendName = "Arnold Rimer"

if ourName < friendName {
    print("It's \(ourName) vs \(friendName)")
}
if ourName > friendName {
    print("It's \(friendName) vs \(ourName)")
}

//if adding a number to an array make it contain more than 3 items remove the oldest one
var numbers = [1, 2, 3]
numbers.append(4)
if numbers.count > 3 {
    numbers.remove(at: 0)
    print(numbers)
}

// == operator !=
let country = "Canada"
if country == "Australia"{
    print("G'day mate")
}
let name = "Taylor Swift"
if name != "Anonymous" {
    print("Welcome \(name)")
}
//if username types nothing for name use anon
var username = ""
//if username.count == 0
//if username.isEmpty == true (faster)
//if username.isEmpty (Better syntax)
if username == "" {
    username = "Anonymous"
}
print("Welcome, \(username).")


//----------------------------------------------------------------------------------------------------------------------------
//
// How to check multiple conditions
//
//----------------------------------------------------------------------------------------------------------------------------

//not efficient version
//ifs
let age2 = 16
if age2 >= 18{
    print("you can vote")
}
if age2 < 18 {
    print("You can't vote yet")
}
//better
//if, else
if age2 >= 18 {
    print("you can vote")
} else {
    print("You can't vote yet")
}
//also if and else if
let a = false
let b = true
if a {
    print("That's not right")
} else if b {
    print("This is the way")
} else {
    print("Something went wrong")
}

//nested if statements
let temp = 25
if temp > 20 {
    if temp < 30 {
        print("There has to be a better way to combine these statements")
    }
}
//better to use && to combine multiple operators
if temp > 20 && temp < 30 {
    print("We used the better way with logical operators")
}
// || is or | is called pipe
let userAge = 14
let parentalConsent = true
if userAge >= 18 || parentalConsent {
    print("You can buy this game.")
}

// combining  if, else if, and || / &&

enum TransportOption {
    case airplane, helicopter, bicycle, car, ecsooter
}

// have to define what transport is at first
// using the type created
var transport = TransportOption.airplane
// once defined you can change it with
transport = .helicopter
transport = .bicycle

if transport == .airplane || transport == .helicopter {
    print("Let's fly.")
} else if transport == .bicycle {
    print("I hope there is a bike path")
} else if transport == .car {
    print("Time to get stuck in traffic")
} else {
    print("I'm going to hire a scooter now")
}


//----------------------------------------------------------------------------------------------------------------------------
//
// How to check switch statements
//
//----------------------------------------------------------------------------------------------------------------------------

//easier to read when there are multiple checks than if statements
enum weatherForcast {
    case sun, rain, wind, snow, unknown
}
var forecast = weatherForcast.wind

if forecast == .sun {
    print("Sunny")
} else if forecast == .rain {
    print("Rain")
} else if forecast == .wind {
    print("Windy")
} else {
    print("The world ended")
}

// Using a switch block is much easier to read
// Switch statements must be exhaustive (include all cases)
// Swift doesn't need a break statement will only do the one that matches
switch forecast {
case .sun:
    print("Sunny")
case .rain:
    print("Rain")
case .wind:
    print("Windy")
case .snow:
    print("Snowing")
case .unknown:
    print("WTF")
}
            
let place = "Metropolis"

// if you put default up higher it will run first and then break out without checking the rest
// probably won't run at all because it doesn't like the default statement above another case.
// just a visual example that would break out before the matching case
switch place {
case "Gotham":
    print("Batman")
case "Mega-City One":
    print("Judge Dredd")
case "Wakanda":
    print("Black Panter")
default:
    print("Who are you?")
//case "Metropolis":
//    print("Superman")
}

// fallthrough makes the switch statement continue
// and print the following statements
let day = 5
print("My true love gave to me...")

switch day {
case 5:
    print("five golden rings")
    fallthrough
case 4:
    print("four calling birds")
    fallthrough
case 3:
    print("three french hens")
    fallthrough
case 2:
    print("two turtle doves")
    fallthrough
default:
    print("and a partridge in a pear tree")
}

//----------------------------------------------------------------------------------------------------------------------------
//
// Ternary condition operator for quick checks
//
//----------------------------------------------------------------------------------------------------------------------------


// Has become important
// ternary operator acts on 3 parts

let age3 = 18
// checks if the condition is true or false age3 >= 18 ?
// returns based on if the condition is true ("Yes") or false ("No")
// condensed form of if statement
// WTF what we checking, if true, if false
let canVote = age3 >= 18 ? "Yes" : "No"
print(canVote)

// logic like switch and if aren't allowed in print statements
// much more efficient than
// if hour < 12 {
//   print("It's before noon")
// } else {
//   print("It's after noon")
// }
let hour = 23
print(hour < 12 ? "It's before noon." : "It's after noon.")

let names2 = ["James", "Kaylee", "Paul"]
let crewCount = names2.isEmpty ? "No Crew" : "there are \(names2.count) crew members"
print(crewCount)

enum Theme {
    case light, dark
}
let theme = Theme.dark

// You can put the condition in () if it helps you read it but not needed
let background = (theme == .dark) ? "Dark mode" : " Light mode"
print(background)


//----------------------------------------------------------------------------------------------------------------------------
//
// How to use for loop to repeat work
//
//----------------------------------------------------------------------------------------------------------------------------

let platforms =  ["iOS", "macOS", "tvOS", "watchOS"]

// loops over platforms and prints the statement each time
for os in platforms {
    // loop body
    // one cycle called loop iteration this has 4
    // os is called the loop variable
    // could have called it anything instead of os just a variable name
    print("Swift works great on \(os).")
}

// can print a range of numbers easily
// with some maths and using string interplation for funsies
// number range number...last number including first number and last number
for i in 1...12 {
    print("5 * \(i) is \(5 * i)")
}

// loop inside loop
// loopception

for i in 1...12 {
    print("This is the \(i) times table")
    
    // loops inside the loop
    for j in 1...12 {
        print("   \(j) x \(i) is \(j * i)")
    }
    // adds a blank line
    print()
}

// range from x to y
for i in 1...5 {
    print("Counting from 1 through 5: \(i)")
}
// range from x up to and excluding y
// use for arrays
for i in 1..<5 {
    print("Counting from 1 up to 5: \(i)")
}

// can use _ if you don't need the i value
var lyric = "Haters gonna"
for _ in 1...5 {
    lyric += " hate"
}
print(lyric)



//----------------------------------------------------------------------------------------------------------------------------
//
// How to use while loop to repeat work
//
//----------------------------------------------------------------------------------------------------------------------------


// less common and less useful as a for loop

var countdown = 10

while countdown > 0 {
    print("\(countdown)...")
    countdown -= 1
}

print("Blast off!")

// random int in range x and y
let id = Int.random(in: 1...1000)
let amount = Double.random(in: 0...1)

// while loop that ends with a critical role
// start by creating the variable
var roll = 0

// while loop to run until a crit at 20
while roll != 20 {
    roll = Int.random(in: 1...20)
    print("You rolled a \(roll)")
}
print("Crit!!!")


//----------------------------------------------------------------------------------------------------------------------------
//
// How to skip loop items with break and continue
//
//----------------------------------------------------------------------------------------------------------------------------

// using continue to skip something
let filenames = ["me.jpg", "work.txt", "sophie.jpg"]

for filename in filenames {
    if filename.hasSuffix(".jpg") == false{
        continue
    }
    print("Found picture: \(filename)")
}

// break exits the entire loop if condition found

let num1 = 4
let num2 = 14
var multiples = [Int]()

for i in 1...100_000 {
    if i.isMultiple(of: num1) && i.isMultiple(of: num2) {
        multiples.append(i)
        
        if multiples.count == 10 {
            break
        }
    }
}
print(multiples)

//----------------------------------------------------------------------------------------------------------------------------
//
// Summary of conditions and loops
//
//----------------------------------------------------------------------------------------------------------------------------
//
// We use if, else, and else if statements to check conditions
// You can combine conditions using && or ||
// switch statements can be easier than using is and else if a lot, and Swift will check that they are exhaustive
// The ternary conditional operator lets us check WTF: What is the condition ? if True do this : else if False do this
// for loops let us loop over arrays, sets, dictionaries, and ranges
// while loops create loops that continue until the conditions are false
// we can skip loop items using continue or break respectively

//----------------------------------------------------------------------------------------------------------------------------
//
// Checkpoint 3
//
//----------------------------------------------------------------------------------------------------------------------------

// Fizzbuzz problem
// loop from 1 to 100
// if multiple of 3 print fizz
// if multiple of 5 print buzz
// if multiple of 3 and 5 print fizzbuzz
// otherwise print the number

let mult3 = 3
let mult5 = 5

for i in 1...100{
    if i.isMultiple(of: mult3) && i.isMultiple(of: mult5) {
        print("FizzBuzz")
    } else if i.isMultiple(of: mult3) {
        print("Fizz")
    } else if i.isMultiple(of: mult5) {
        print("Buzz")
    } else {
        print(i)
    }
}

